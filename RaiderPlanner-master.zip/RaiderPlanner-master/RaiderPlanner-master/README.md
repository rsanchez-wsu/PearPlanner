# RaiderPlanner
#### The best study planner since the Gantt Diagram

Please have a look at the [project website](https://rsanchez-wsu.github.io/RaiderPlanner)(old website) for information about RaiderPlanner.

If you would like to contribute to RaiderPlanner, then please read about configuring the [development toolchain](TOOLCHAIN.md) and then read the [contributor guidelines](CONTRIBUTING.md).


| Branch  | Build status  |
| ------------- | ------------- |
| gzdwsu/master: | [![Build Status](https://api.travis-ci.org/gzdwsu/RaiderPlanner.svg?branch=master)](https://travis-ci.org/gzdwsu/RaiderPlanner)  |



