IMAGE CREDITS:
MainMenu.fxml:
settings_icon.png - GIMP image, created by Clayton D. Terrill

Settings.fxml:
settings_about.png - GIMP image, created by Clayton D. Terrill
settings_account.png - GIMP image, created by Clayton D. Terrill
settings_general.png - GIMP image, created by Clayton D. Terrill
settings_goBack.png - GIMP image, created by Clayton D. Terrill
settings_theme.png - GIMP image, created by Clayton D. Terrill
information.png - https://www.flaticon.com/free-icon/info_131917#term=information&page=1&position=10