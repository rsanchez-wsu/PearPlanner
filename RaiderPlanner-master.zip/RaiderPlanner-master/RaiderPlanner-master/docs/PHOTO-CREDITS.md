# PHOTO CREDITS AND COPYRIGHTS:

RaiderPlanner/docs/assets/img/calendar.png - ICONSHOP, https://freeiconshop.com/icon/calendar-icon-outline-filled/

RaiderPlanner/docs/assets/img/reminder.png - Incenticon, http://www.myiconfinder.com/icon/timer-alarm-bell-business-clockcounter-event-history-hour-minute-plan-reminder-schedule-stopwatch-time-time-management-timertiming-wait-lap-lap-time-waiting-watch-history/936 

RaiderPlanner/docs/assets/img/gantt.png - ConceptDraw, http://www.conceptdraw.com/examples/icon-project-management 
 
RaiderPlanner/docs/assets/img/pearplanner.jpg - screen shot of RaiderPlanner program, taken by James Languirand 

RaiderPlanner/docs/assets/img/pearplannerThumb.jpg - screen shot of RaiderPlanner program, taken by James Languirand 

RaiderPlanner/docs/assets/img/classPicture.jpg - taken by Kat 

RaiderPlanner/docs/assets/img/classPictureThumb.jpg - taken by Kat

RaiderPlanner/docs/assets/img/movingforward.jpeg - photographer unknown, retrieved from http://businessessays.net/operationmanagement/project-planning-techniques-cpa-pert-and-gantt-charts/ 


RaiderPlanner/docs/assets/img/movingforwardThumb.jpeg - photographer unknown, retrieved from http://businessessays.net/operationmanagement/project-planning-techniques-cpa-pert-and-gantt-charts/ 
 
RaiderPlanner/docs/assets/img/code.jpg - screen shot of RaiderPlanner source code, taken by James Languirand 

RaiderPlanner/docs/assets/img/codeThumb.jpg - screen shot of RaiderPlanner source code, taken by James Languirand 

RaiderPlanner/docs/assets/img/download.jpg - Kliponius, https://openclipart.org/detail/201887/download-button-green 

RaiderPlanner/docs/assets/img/new.png - created by Yousif sobhi

RaiderPlanner/docs/assets/img/favnew.png - created by Yousif Sobhi



# Bootstrap copyright and licenes  
Copyright (c) 2011-2018 Twitter, Inc. 

Copyright (c) 2011-2018 The Bootstrap Authors 

https://github.com/twbs/bootstrap/blob/master/LICENSE

# Images from unsplach
All other images are taken from the open source unsplach.

unsplash License Link: https://unsplash.com/license

RaiderPlanner/docs/assets/img/home-bg.jpg - created by JESHOOTS.COM, https://unsplash.com/photos/pUAM5hPaCRI

RaiderPlanner/docs/assets/img/about/1.jpg - created by rawpixel, https://unsplash.com/photos/1GepXKtYUK8

RaiderPlanner/docs/assets/img/about/2.jpg - created by José Martín Ramírez C, https://unsplash.com/photos/Gauk-pFdvKk

RaiderPlanner/docs/assets/img/about/3.jpg - created by Aleksi Tappura, https://unsplash.com/photos/PjH_BkzjxTA

RaiderPlanner/docs/assets/img/about/4.jpg - created by Benjamin Voros, https://unsplash.com/photos/phIFdC6lA4E

RaiderPlanner/docs/assets/img/Help.jpg - created by Russ Ward, https://unsplash.com/photos/bqzLehtF8XE
