Additional permission under GNU GPL version 3 section 7

If you modify this Program, or any covered work, by linking or combining it with JUnit, JUnit's dependencies, or a modified version of JUnit or its dependencies, containing parts covered by the terms of Eclipse Public License version 1.0 (or any later version), the licensors of this Program grant you additional permission to convey the resulting work.
